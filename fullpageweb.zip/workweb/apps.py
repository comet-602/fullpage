from django.apps import AppConfig


class WorkwebConfig(AppConfig):
    name = 'workweb'
