$(document).ready(function(){
	$("button").click(function(){
		$("#div1").load("/static/img/text.txt");
	});
});